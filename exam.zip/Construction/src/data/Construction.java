package data;
public class Construction {
	private int idConstruction;
	protected double Superficie;
}