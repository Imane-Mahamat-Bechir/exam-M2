import data.Contact;

public class dataConstruction {
	public static Construction [] lstConstruction= {new Construction(),
}
