package metier;

import java.util.List;

import javax.ejb.Remote;
import entities.Construction;

@Remote
public interface GestionConstruction {
	public void ajouter(Construction construction);
	public Construction lister(int id);
	public List<Construction> listerConstruction();
	

}
