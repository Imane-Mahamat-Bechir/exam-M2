package metier;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import entities.Construction;


@Stateless( name="gCBean")

public class GestionConstructionBean implements GestionConstruction{
	@PersistenceContext(unitName="Projet_Construction")
   EntityManager em;
	public void ajouterConstruction(Construction Const) {
	      em.persist(Const);
		// TODO Auto-generated method stub
		
	}


	@Override
	public List<Construction> listerConstruction() {
		Query requete=em.createQuery("select");
		return requete.getResultList();
		// TODO Auto-generated method stub
		
	}


	@Override
	public Construction lister(int id) {
		
		Query requete = em.createQuery("SELECT C FROM Construction C WHERE C.idConstruction = "+id);
		return (Construction)requete.getSingleResult();
	}


	@Override
	public void ajouter(Construction construction) {
		// TODO Auto-generated method stub
		
	}

	
	}

	

	


