package entities;

import java.util.List;

import javax.persistence.Entity;

@Entity
public class Hopital extends Construction{

	private String Categorie;
	public Hopital() {
		
		super();
	}
	public Hopital(String categorie, double superficie, Plan plan, List<Intervenant> Intervenant) {
		super(superficie, plan, Intervenant);
		Categorie = categorie;
		
	}
	public String getCategorie() {
		return Categorie;
	}
	public void setCategorie(String categorie) {
		Categorie = categorie;
	}
	
}
