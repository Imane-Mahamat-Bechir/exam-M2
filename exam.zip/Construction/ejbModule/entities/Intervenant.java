package entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Intervenant implements Serializable{
	@Id
	@GeneratedValue
	private int idIntervenant;
	private String nomIntervenant;
	public int getIdIntervenant() {
		return idIntervenant;
	}
	public void setIdIntervenant(int idIntervenant) {
		this.idIntervenant = idIntervenant;
	}
	public String getNomIntervenant() {
		return nomIntervenant;
	}
	public void setNomIntervenant(String nomIntervenant) {
		this.nomIntervenant = nomIntervenant;
	}
	public Intervenant() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Intervenant(int idIntervenant, String nomIntervenant) {
		super();
		this.idIntervenant = idIntervenant;
		this.nomIntervenant = nomIntervenant;
	}
	

}
