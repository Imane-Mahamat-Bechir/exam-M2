package entities;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
public class Construction implements Serializable{
	@Id
	@GeneratedValue
	private int idConstruction;
	protected double Superficie;

	
	
	@OneToOne
	protected
    Plan plan;
	@ManyToMany
	@JoinColumn(name="id_Intervenant")
	protected List<Intervenant>Intervenant = new LinkedList<Intervenant>();
	
	
	public Construction() {
	}

	public int getIdConstruction() {
		return idConstruction;
	}

	public void setIdConstruction(int idConstruction) {
		this.idConstruction = idConstruction;
	}

	public double getSuperficie() {
		return Superficie;
	}

	public void setSuperficie(int superficie) {
		Superficie = superficie;
	}
	public Plan getPlan() {
		return plan;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}

	public List<Intervenant> getInterv() {
		return Intervenant ;
	}

	public void setInterv(List<Intervenant> interv) {
		this.Intervenant  = interv;
	}

	public Construction(Plan plan, double superficie, List<Intervenant>Intervenant ) {
		super();
		this.plan = plan;
		this.Superficie = superficie;
		this.Intervenant = Intervenant;
	}

	public Construction(double superficie2, Plan plan2, List<entities.Intervenant> intervenant2) {
		// TODO Auto-generated constructor stub
	}

	
	
}
