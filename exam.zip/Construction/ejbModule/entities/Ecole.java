package entities;

import java.util.List;

//public interface Ecole implements Construction{@Entity
public class Ecole extends Construction{

	private int nbreSalle;
	public Ecole() 
	
	{
		super();
	}
	public Ecole(int nbreSalle, double superficie, Plan plan, List<Intervenant> Intervenant ) 
	{
		
		this.nbreSalle = nbreSalle;
		this.Superficie = superficie;
		this.Intervenant = Intervenant;
	}
	public int getNbreSalle() {
		return nbreSalle;
	}
	public void setNbreSalle(int nbreSalle) {
		this.nbreSalle = nbreSalle;
	}

}
