package entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Architecte implements Serializable {

	@Id
	@GeneratedValue
	private int idArchitecte;
	
	private String NomArchitecte;

	public int getIdArchitecte() {
		return idArchitecte;
	}

	public void setIdArchitecte(int idArchitecte) {
		this.idArchitecte = idArchitecte;
	}

	public String getNomArchitecte() {
		return NomArchitecte;
	}

	public void setNomArchitecte(String nomArchitecte) {
		NomArchitecte = nomArchitecte;
	}

	public Architecte(int idArchitecte, String nomArchitecte) {
		super();
		this.idArchitecte = idArchitecte;
		NomArchitecte = nomArchitecte;
	}

	public Architecte() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
