package entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;


@Entity
public class Plan implements Serializable{
	@Id
	@GeneratedValue
	
	private int idPlan;
	private int numArchive;
	
	@ManyToOne
	@JoinColumn(name="idArchitecte")

	private Architecte architecte;@JoinColumn(name="idConstruct")
	private Construction idConstruct;
	public int getIdPlan() {
		return idPlan;
	}
	public void setIdPlan(int idPlan) {
		this.idPlan = idPlan;
	}
	public int getNumArchive() {
		return numArchive;
	}
	public void setNumArchive(int numArchive) {
		this.numArchive = numArchive;
	}
	public Construction getIdConstruct() {
		return idConstruct;
	}
	public void setIdConstruct(Construction idConstruct) {
		this.idConstruct = idConstruct;
	}
	public Plan(int idPlan, int numArchive, Construction idConstruct) {
		super();
		this.idPlan = idPlan;
		this.numArchive = numArchive;
		this.idConstruct = idConstruct;
	}
	public Plan() {
		super();
		// TODO Auto-generated constructor stub
	} 
	

}
